# Aplikasi QR Code dan FPDF

- Library yang digunakan :

 1. phpqrcode
 2. fpdf 
 3. Web : Bootstrap + JQuery

- Pendukung Installasi Aplikasi

 1. XAMPP Version 5.5.38
 2. Web Browser Terbaru (Chrome & Mozilla Firefox) 
 3. Configurasi Database pada folder : inc/conf.php 
 4. Username dan Password : admin

- Fitur Aplikasi :

 1. Mengelola Data QR Code
 2. Cetak QR Code HTML
 3. Cetak QR Code PDF
