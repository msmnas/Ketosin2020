<h3>Selamat Datang di Aplikasi QR Code</h3>

<h4 class="page-header">Fitur Aplikasi</h4>
<ul>
	<li>Menginput Code QR Code</li>
	<li>Mencetak QR Code</li>
	<li>Menampilkan QR Code di PDF</li>
</ul>