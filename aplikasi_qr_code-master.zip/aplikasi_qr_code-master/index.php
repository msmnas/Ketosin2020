<?php
	header("location:med.php?mod=dashboard");
?>